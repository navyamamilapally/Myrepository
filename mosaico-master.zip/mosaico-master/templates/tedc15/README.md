An example port of [TEDC15 Template](https://github.com/fcarneiro/tedc15_template) to Mosaico!
