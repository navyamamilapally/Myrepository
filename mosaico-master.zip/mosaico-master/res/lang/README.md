This files are not yet directly used by mosaico.

You can use ```Mosaico.init({ strings: #thecontentofoneofthisfiles# })``` to initialize mosaico in a given language.

You can provide new translations to our mosaico translations project on Transifex: https://www.transifex.com/void-labs/mosaico

Please get in touch with me by sending an email to info on the mosaico.io domain including your email and the language you'd like to contribute.

Thanks to translators:
it (Italian): Mosaico Team
de (German): Bernhard Weichel
es (Spanish): Carlos Jacobs
fr (French): Jonathan Loriaux
nl (Dutch): Pieter Emeis
sv (Swedish): P-H Westman

Sign-up to Transifex if you want to collaborate or suggest changes to the current languages!
